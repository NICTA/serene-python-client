#include "core/propagator.h"
#include "mip/mip.h"
#include "LiMDD/MDD.h"
#include "LiMDD/LIA_commons.h"
#include <vector>

#include <unordered_map>

// sum x_i >= c <- r
// Only use scale and minus views. Absorb offsets into c.


#define MIN(a,b) ((a<b)?a:b)

void postClauses(std::vector<std::vector<Lit> >& newClauses) {
    for (uint i = 0; i < newClauses.size(); i++) {
        vec<Lit> ps;
        for (uint j = 0; j < newClauses[i].size(); j++) {
            ps.push(newClauses[i][j]);
        }
        sat.addClause(ps);
    }
}

template <int S, int R = 0>
class LinearGE : public Propagator {
	vec<int> pos;
    vector<int> coeffsLE;
    int rhsLE;
	vec<IntView<2*S> > x;
	vec<IntView<2*S+1> > y;
	int const c;
	BoolView r;
        
	// persistent data
	int fix;
	int fix_x;
	int fix_y;
	int64_t fix_sum;
	vec<Lit> ps;
        
    //Caching
    int const sz;
    int const key_sz;
    Tint* fixed;
    Tint num_fixed;
        Tint sum_fixed;
        int sp;
public:

	LinearGE(vec<int>& a, vec<IntVar*>& _x, int _c, BoolView _r = bv_true) :
            pos(_x.size()), coeffsLE(a.size()), c(_c), r(_r), fix(0), fix_x(0), 
            fix_y(0), fix_sum(-c), ps(R+_x.size()),
        sz(_x.size()),key_sz((sz+31)/32), fixed(new Tint[key_sz]),num_fixed(0),sum_fixed(0) {
		priority = 2;
                // printf("LinearGE is propagator %d\n",prop_id);
                // printf("a = ");
                // for (int i = 0; i < a.size(); i++) {
                //     printf("%d * [%d,%d] ",a[i],_x[i]->getMin(),_x[i]->getMax());
                // }
                // printf(">= %d",c);
                // printf("\n");
                assert(_x.size() == a.size());
                for (int i = 0; i < key_sz; i++) fixed[i] = 0;
                sp = 0;
		for (int i = 0; i < _x.size(); i++) {
			assert(a[i]);
			if (a[i] > 0) {
				pos[i] = x.size();
				x.push(IntView<2*S>(_x[i], a[i]));
                                sp++;
				_x[i]->attach(this, x.size() - 1, EVENT_LU);
                                //coeffsLE[x.size()-1] = -a[i];
                        }
		}

		for (int i = 0; i < _x.size(); i++) {
			assert(a[i]);
			if (a[i] < 0) {
				pos[i] = -y.size()-1;
				y.push(IntView<2*S+1>(_x[i], -a[i]));
				_x[i]->attach(this, y.size()+sp - 1, EVENT_LU);
                                //coeffsLE[x.size()+y.size()-1] = -a[i];
			}
		}
		if (R) r.attach(this, _x.size(), EVENT_L);
                rhsLE = -c;

                for (int i = 0; i < x.size(); i++) num_fixed += x[i].isFixed();
                for (int i = 0; i < y.size(); i++) num_fixed += y[i].isFixed();
                for (int i = 0; i < x.size(); i++) sum_fixed += (x[i].isFixed()? x[i].getVal() : 0);
                for (int i = 0; i < y.size(); i++) sum_fixed += (y[i].isFixed()? y[i].getVal() : 0);

	}


	void wakeup(int i, int c) {
		if (!R || !r.isFalse()) pushInQueue();
                if (i >= 0 && i < pos.size()) {
                    bool f = false;
                    if (i < sp && x[i].isFixed()) {
                        f = true;
                        sum_fixed += x[i].getVal();
                    }
                    if (i >= sp  && y[i-sp].isFixed()) {
                        f = true;
                        sum_fixed += y[i-sp].getVal();
                    }
                    if (f) {
                        num_fixed = num_fixed + 1;
                        fixed[i/32] = fixed[i/32]^bit32[i%32];
                    }
                }
	}

	bool propagate() {
		if (R && r.isFalse()) return true;
                
                int64_t max_sum = fix_sum;
                
		for (int i = fix_x; i < x.size(); i++) max_sum += x[i].getMax();
		for (int i = fix_y; i < y.size(); i++) max_sum += y[i].getMax();

//		if (R && max_sum < 0) setDom2(r, setVal, 0, x.size()+y.size());

		if (R && max_sum < 0) {
			int64_t v = 0;
			if (r.setValNotR(v)) {
                            Reason expl;
				if (so.lazy) {
					for (int j = 0; j < x.size(); j++) ps[j+1] = x[j].getMaxLit();
					for (int j = 0; j < y.size(); j++) ps[j+1+x.size()] = y[j].getMaxLit();
					expl = Reason_new(ps);
                                        //expl->padding = prop_id;
                                        //Clause::clause2prop[expl] = prop_id;
				}
				if (!r.setVal(v, expl)) return false;
			}
		}




		if (R && !r.isTrue()) return true;

//		for (int i = fix_x; i < x.size(); i++) {
//			setDom2(x[i], setMin, x[i].getMax()-max_sum, i);
//		}

//		for (int i = fix_y; i < y.size(); i++) {
//			setDom2(y[i], setMin, y[i].getMax()-max_sum, x.size()+i);
//		}

		for (int i = fix_x; i < x.size(); i++) {
			int64_t v = x[i].getMax()-max_sum;
			if (x[i].setMinNotR(v)) {
				Reason expl;
				if (so.lazy) {
					if (R && r.isFixed()) ps[0] = r.getValLit();
					for (int j = 0; j < x.size(); j++) ps[j+R] = x[j].getMaxLit();
					for (int j = 0; j < y.size(); j++) ps[j+R+x.size()] = y[j].getMaxLit();
					ps[R+i] = ps[0];
					expl = Reason_new(ps);
				}
				if (!x[i].setMin(v, expl)) return false;
			}

		}

		for (int i = fix_y; i < y.size(); i++) {
			int64_t v = y[i].getMax()-max_sum;
			if (y[i].setMinNotR(v)) {
				Reason expl;
				if (so.lazy) {
					if (R && r.isFixed()) ps[0] = r.getValLit();
					for (int j = 0; j < x.size(); j++) ps[j+R] = x[j].getMaxLit();
					for (int j = 0; j < y.size(); j++) ps[j+R+x.size()] = y[j].getMaxLit();
					ps[R+x.size()+i] = ps[0];
					expl = Reason_new(ps);
                                        //expl->padding = prop_id;
                                        //Clause::clause2prop[expl] = prop_id;
				}
				if (!y[i].setMin(v, expl)) return false;
			}
		}

		return true;
	}

	Clause* explain(Lit p, int inf_id) {
        if (inf_id == x.size()+y.size()) inf_id = -1;
		if (R && r.isFixed()) ps[0] = r.getValLit();
		for (int i = 0; i < x.size(); i++) ps[i+R] = x[i].getMaxLit();
		for (int i = 0; i < y.size(); i++) ps[i+R+x.size()] = y[i].getMaxLit();
		ps[R+inf_id] = ps[0];                
		Clause* tmp = Reason_new(ps);
                //tmp->padding = prop_id;
                //Clause::clause2prop[tmp] = prop_id;
                return tmp;
	}


    void simplify() {
        return;
        //printf("####################################\n");
        if (simplified) return;
        if (engine.decisionLevel() != 0) return;
        simplified = true;

        std::unordered_map<int,IntVar*> intvars;

        /*printf("Simplify LinearGE:\n");
        for (int i = 0; i < coeffsLE.size(); i++) {
            if(pos[i] >= 0)
                printf("%d * [%d,%d] ",coeffsLE[i],x[pos[i]].getVar()->getMin(),x[pos[i]].getVar()->getMax());
            else
                printf("%d * [%d,%d] ",coeffsLE[i],y[-pos[i]-1].getVar()->getMin(),y[-pos[i]-1].getVar()->getMax());
        }
        printf("<= %d",rhsLE);
        printf("\n");//*/

        //printf("a's: ");
        coeffsLE.clear();
        std::vector<std::vector<Lit> > lits;     
        for (unsigned int i = 0; i < x.size() + y.size(); i++) {
            if(pos[i] >= 0) {
                if(x[pos[i]].getVar()->getMax() <= 0) continue;
                lits.push_back(std::vector<Lit>());
                for (int j = 0; j < x[pos[i]].getVar()->getMax(); j++) {
                    lits.back().push_back(x[pos[i]].getVar()->getLit(j,3));
                    intvars[var(lits.back().back())] = x[pos[i]].getVar(); //Same var for all lits
                }
                //printf("%d ",-x[pos[i]].a);
                coeffsLE.push_back(-x[pos[i]].a);
            } else {
                if(y[-pos[i]-1].getVar()->getMax() <= 0) continue;
                lits.push_back(std::vector<Lit>());
                for (int j = 0; j < y[-pos[i]-1].getVar()->getMax(); j++) {
                    lits.back().push_back(y[-pos[i]-1].getVar()->getLit(j,3));
                    intvars[var(lits.back().back())] = y[-pos[i]-1].getVar(); //Same var for all lits
                }
                //printf("%d* ",y[-pos[i]-1].a);
                coeffsLE.push_back(y[-pos[i]-1].a);
            }
        }
        //printf("\n");
        /*
        printf("lits: ");
        for (int i = 0; i < lits.size(); i++) {
            for (int j = 0; j < lits[i].size(); j++) {
                printf("%d ",toInt(lits[i][j]));
            }
            printf(" |");
        }
        printf("\n");
        printf("coeffs: ");
        for (int i = 0; i < coeffsLE.size(); i++) {
            printf("%d ",coeffsLE[i]);
            printf(" |");
        }
        printf("\n");
        */
        simplified = true;
        
        //Normalize:
        LIA_Commons::normalize(lits, coeffsLE, rhsLE, false);
        /*printf("Normalize\n");
        printf("lits: ");
        for (int i = 0; i < lits.size(); i++) {
            for (int j = 0; j < lits[i].size(); j++) {
                printf("%d ",toInt(lits[i][j]));
            }
            printf(" |");
        }
        printf("\n");
        */
        int K = rhsLE;

        //printf("K = %d\n",K);

        std::vector<std::vector<Lit> > newClauses;

        if ( K < 0 ) {
            return;
        }

        vector<vector<Lit> > l2(lits);
        vector<int> c2(coeffsLE);

        /*printf("l2: ");
        for (int i = 0; i < l2.size(); i++) {
            for (int j = 0; j < l2[i].size(); j++) {
                printf("%d ",toInt(l2[i][j]));
            }
            printf(" |");
        }
        printf("\n");
        printf("c2: ");
        for (int i = 0; i < c2.size(); i++) {
            printf("%d ",c2[i]);
            printf(" |");
        }
        printf("\n");
        */

        for (uint i = 0; i < l2.size(); i++) {
            if ( c2[i]*l2[i].size() > K ) {
                newClauses.push_back(vector<Lit>(1, l2[i][K/c2[i]]));
                l2[i].resize(K/c2[i]);
                if (l2[i].size() == 0 ) {
                    if ( i < l2.size()-1 ) {
                        l2[i].swap(l2.back());
                        c2[i] = c2.back();
                    }
                    l2.pop_back();
                    c2.pop_back();
                    i--;
                }
            }
        }


        /*printf("l2: ");
        for (int i = 0; i < l2.size(); i++) {
            for (int j = 0; j < l2[i].size(); j++) {
                printf("%d ",toInt(l2[i][j]));
            }
            printf(" |");
        }
        printf("\n");
        printf("c2: ");
        for (int i = 0; i < c2.size(); i++) {
            printf("%d ",c2[i]);
            printf(" |");
        }
        printf("\n");
        */
        
        int base_lit = sat.getLazyVar(); 
        //printf("base_lit is %d\n",base_lit);

        if ( l2.size() == 0 ) {
            postClauses(newClauses);
            return; 
        }
        uint s=0;
        for (uint i = 0; i < l2.size(); i++) s+=c2[i]*l2[i].size();
        if ( s <= K ) { 
            postClauses(newClauses);
            return; 
        }

        //printf("s = %d\n",s);

        uint bl = base_lit;
        LIA_Commons::sort(l2, c2, false);


        /*printf("l2: ");
        for (int i = 0; i < l2.size(); i++) {
            for (int j = 0; j < l2[i].size(); j++) {
                printf("%d ",toInt(l2[i][j]));
            }
            printf(" |");
        }
        printf("\n");
        printf("c2: ");
        for (int i = 0; i < c2.size(); i++) {
            printf("%d ",c2[i]);
            printf(" |");
        }
        printf("\n");
        */

        std::vector<std::vector<Lit> > l3;
        std::vector<int> c3;

        l3 = l2; c3 = c2;
        /*
        for (uint i = 0; i < l2.size(); i++) {
            uint ini = i;
            while( i < l2.size()-1 && c2[i] == c2[i+1] ) i++;
            if (c2[i] == 0 ) continue;
            std::vector<Lit> V(l2[ini].size());
            for (uint j =0; j < l2[ini].size(); j++) V[j]=~l2[ini][j];
            for (uint j = ini+1; j <= i; j++) {
                std::vector<Lit> aux;
                std::vector<Lit> aux2(l2[j].size());
                for (uint k =0; k < l2[j].size(); k++) aux2[k]=~l2[j][k];
                simpMerge.createNetwork(V, aux2, aux, K/(c2[ini])+1, bl, newClauses);
                V = aux;
            }
            for (uint j =0; j < V.size(); j++) V[j]=~V[j];
            while ( V.size() * c2[ini] > K ) {
                newClauses.push_back(std::vector<Lit>(1,V.back()));
                V.pop_back();
            }
            l3.push_back(V);
            c3.push_back(c2[ini]);
            }*/


        // printf("l3: ");
        // for (int i = 0; i < l3.size(); i++) {
        //     for (int j = 0; j < l3[i].size(); j++) {
        //         printf("%d ",toInt(l3[i][j]));
        //     }
        //     printf(" |");
        // }
        // printf("\n");
        // printf("c3: ");
        // for (int i = 0; i < c3.size(); i++) {
        //     printf("%d ",c3[i]);
        //     printf(" |");
        // }
        // printf("\n");


        base_lit = bl;

        s = 0;
        for (uint i = 0; i < l3.size(); i++) s+=c3[i]*l3[i].size();
        //printf(" s = %d and K = %d\n",s,K);
        if ( s <= K ) {
            postClauses(newClauses);
            return;
        }

        //vector<int> dom(l3.size());
        //for(uint i = 0; i < l3.size(); i++) dom[i]=l3[i].size();
        vector<IntVar*> dom(l3.size());
        for(uint i = 0; i < l3.size(); i++) {
            //printf("IntVar %d, %d %d\n",i, intvars[var(l3[i][0])]->getMax(),l3[i].size());
            if (intvars[var(l3[i][0])]->getMax() > l3[i].size())
                intvars[var(l3[i][0])]->setMax(l3[i].size());
            dom[i] = intvars[var(l3[i][0])];
        }

        LiMDD mdd2;


        // printf("c3x: ");
        // for (int i = 0; i < c3.size(); i++) {
        //     printf("%d ",c3[i]);
        //     printf(" |");
        // }
        // printf("\n");
        // printf("dom: ");
        // for (int i = 0; i < dom.size(); i++) {
        //     printf("%d ",dom[i]);
        //     printf(" |");
        // }
        // printf("\n");

        mdd2.defineConstraint(c3, dom);

        LiMDD::NodeID node;
        LiMDD::NodeID root = mdd2.newRoot(K);
        if ( mdd2.isTerminal(root) ) {
            if (mdd2.isTrue(root)) {
                postClauses(newClauses);
                return;
            }
            return;
        }

        node = mdd2.getFirstNode();
        
        //printf("MDD for constraint %d:\n",prop_id);
        //mdd2.printMDD();
        int nc,ec;
        mdd2.computeSize(nc,ec);
        //printf("Nodes count %d, Edge count %d\n",nc,ec);
        mdd2.slimMDD(l3);
        int nc2,ec2;
        mdd2.computeSize(nc2,ec2);        
        //printf("Nodes count %d, Edge count %d\n",nc,ec);
        /*fprintf(stderr,"[%d][Used %d] <%d> >= %d\n =>",prop_id,Clause::prop2contrib[prop_id],coeffsLE.size(),rhsLE);
        for (int i = 0; i < x.size(); i++) {
            fprintf(stderr,"%d, ",x[i].var->expl_appear);
        }        
        for (int i = 0; i < y.size(); i++) {
            fprintf(stderr,"%d, ",y[i].var->expl_appear);
        }        
        fprintf(stderr,"\n%d,%d,%d,%d, %lf, %lf\n",nc,nc2,ec,ec2,nc2/(float)nc,ec2/(float)ec);
        //*/
        //printf("After\n");
        //mdd2.printMDD();
        //printf("bl is == %d",bl);

        while(true) {
            //printf("Creating clauses from %d\n",node);
            if (!mdd2.isTerminal(node)) {
                {
                    uint nS = mdd2.getNumSons(node);
                    bool found_t = false;
                    bool found_f = false;
                    vector<LiMDD::NodeID> to_remove;
                    for (uint i = 0; i < nS; i++) { //Remove duplicate terminals
                        LiMDD::NodeID current = mdd2.getSon(node,i);
                        //printf("child %d  [%d %d | %d %d]\n",current,mdd2.isTerminal(current),mdd2.isTrue(current),found_t,found_f);
                        if (mdd2.isTerminal(current)) {
                            if (mdd2.isTrue(current)) {
                                if (found_t) to_remove.push_back(current);
                                else found_t = true;
                            } else {
                                if (found_f) to_remove.push_back(current);
                                else found_f = true;
                            }
                        }
                    }
                    for (int i = 0; i < to_remove.size(); i++) {
                        //printf("Remove %d\n",to_remove[i]);
                        mdd2.removeSon(node,to_remove[i]);
                    }

                }
                uint nS = mdd2.getNumSons(node);
                if ( mdd2.getSon(node,0) == mdd2.getSon(node, nS-1) ) { // Long edge node.
                    //printf("ifif\n");
                    if ( mdd2.isTerminal(mdd2.getSon(node,0)) )	
                        mdd2.setTerminal(node, mdd2.isTrue(mdd2.getSon(node,0)) );
                    else 
                        mdd2.setVar(node,mdd2.getVar(mdd2.getSon(node,0)));
                } else {
                    //printf("ifelse\n");
                    LiMDD::NodeID last = node; // No last.
                    for (uint i = 0; i < nS; i++) {
                        LiMDD::NodeID current = mdd2.getSon(node,i);
                        if ( last != current ) {
                            last = current;
                            if (mdd2.isTerminal(current)) {
                                if (!mdd2.isTrue(current)) {
                                    // Current is the false node. Clause "node -> lit < i" is needed (or, equiv., 'NEG n' OR 'lit <= i-1').g
                                    assert(i>0);
                                    newClauses.push_back(vector<Lit>(2));
                                    newClauses.back()[0]=Lit(bl,0);
                                    newClauses.back()[1]=l3[mdd2.getLevel(node)][i-1];
                                    // printf("Adding clause \n");
                                    // for (uint j = 0; j < newClauses.back().size(); j++) 
                                    //     cout << toInt(newClauses.back()[j]) << " ";
                                    // cout << 0 << endl;

                                } // No else: if current is the true node, nothing is needed.
                            } else {
                                // General case: "n AND 'lit >= i' -> current"
                                newClauses.push_back(vector<Lit>());
                                newClauses.back().push_back(Lit(bl,0));
                                if (i > 0) {
                                    newClauses.back().push_back(l3[mdd2.getLevel(node)][i-1]);
                                }
                                // Note: if i = 0, 'lit >= i' is a tautology
                                newClauses.back().push_back(Lit(mdd2.getVar(current),1));
                                // printf("Adding clause: %d %d\n",
                                //        toInt(Lit(mdd2.getVar(current),0)),
                                //        toInt(Lit(mdd2.getVar(current),1)));
                                // for (uint j = 0; j < newClauses.back().size(); j++) 
                                //     cout << toInt(newClauses.back()[j]) << " ";
                                // cout << 0 << endl;
                            }
                        }
                    }
                    //printf("Node %d is set to variable %d, which has lits %d %d\n",node, bl,toInt(Lit(bl,0)),toInt(Lit(bl,1)));
                    mdd2.setVar(node, bl);
                    bl = sat.getLazyVar();
                }
            }
            if (mdd2.isLast(node)) break;
            else node = mdd2.nextNode(node);
        }

        assert(node == root);
        //newClauses.push_back(vector<Lit>(1,Lit(mdd2.getVar(root),1)));
        base_lit=bl;

        // cout << "**************************" << endl;
        // for (uint i = 0; i < newClauses.size(); i++) {
        //     for (uint j = 0; j < newClauses[i].size(); j++) 
        //         cout << toInt(newClauses[i][j]) << " ";
        //     cout << 0 << endl;
        // }

        postClauses(newClauses);
        
        simplified = true;
    }


    void getKey() {
        if (num_fixed == 0 && (!R || !r.isFixed())) return;
        if (!r.isFixed()) {
            core_key.push(prop_id);
            core_key.push(sum_fixed);
            core_key.push(0);
        } else if (r.isTrue()) {
            core_key.push(prop_id);
            core_key.push(sum_fixed);
            core_key.push(1);
        } else {
            //No need, empty key
        }
        return;
        

		// Inactive
		if (num_fixed == 0 && (!R || !r.isFixed())) return;
		// Redundant
		if (r.isFalse()) return;
		// Get key
		if (r.isTrue()) {
			core_key.push(prop_id);
			for (int i = 0; i < key_sz; i++) core_key.push(fixed[i]);
			dom_key.push(prop_id);
			dom_key.push(sum_fixed);
			dom_key[0]++;
		} else {
			core_key.push(prop_id);
			for (int i = 0; i < key_sz; i++) core_key.push(fixed[i]);
			core_key.push(sum_fixed);
		}
    }

};


//-----

// sum x_i != c <- r

template <int U, int V, int R = 0>
class LinearNE : public Propagator {
	int sp;
	int const sz;
	IntView<U> * x;
	IntView<V> * y;
	int const c;
	BoolView r;

	// persistent state

	Tint num_unfixed;
	Tint64_t sum_fixed;

public:

	LinearNE(vec<int>& a, vec<IntVar*>& _x, int _c, BoolView _r = bv_true) :
		sz(_x.size()), c(_c), r(_r), num_unfixed(sz), sum_fixed(-c) {
                    //printf("LinearNE is propagator %d\n",prop_id);

		vec<IntView<0> > w;
		for (int i = 0; i < a.size(); i++) {
			if (a[i] >= 0) w.push(IntView<0>(_x[i], a[i]));
		}
		sp = w.size();
		for (int i = 0; i < a.size(); i++) {
			if (a[i] < 0) w.push(IntView<0>(_x[i], -a[i]));
		}
		x = (IntView<U> *) (IntView<0> *) w;
		y = (IntView<V> *) (IntView<0> *) w;
		w.release();

		for (int i = 0 ; i < sz; i++) x[i].attach(this, i, EVENT_F);
		if (R) r.attach(this, sz, EVENT_L);
//		printf("LinearNE: %d %d %d %d %d\n", sp, sz, U, V, R);
	}

	void wakeup(int i, int c) {
		if (i < sz) {
			num_unfixed = num_unfixed - 1;
			if (i < sp) sum_fixed = sum_fixed + x[i].getVal();
			else        sum_fixed = sum_fixed + y[i].getVal();
		}
		if (num_unfixed > 1) return;
		if (!R || r.isTrue() || (!r.isFixed() && num_unfixed == 0)) pushInQueue();
	}

	bool propagate() {
		if (R && r.isFalse()) return true;

		assert(num_unfixed <= 1);
		
		if (num_unfixed == 0) {
			if (sum_fixed == 0) {
				Clause *m_r = NULL;
				if (so.lazy) {
					m_r = Reason_new(sz+1);
                                        //m_r->padding = prop_id;
                                        //Clause::clause2prop[m_r] = prop_id;
					for (int i = 0; i < sz; i++) (*m_r)[i+1] = x[i].getValLit();
				}
				return r.setVal(0, m_r);
			}
			return true;
		}

		if (R && !r.isTrue()) return true;

		assert(num_unfixed == 1);

		int k = 0;
		while (x[k].isFixed()) k++;
		assert(k < sz);
		for (int i = k+1; i < sz; i++) assert(x[i].isFixed());

		if ((k < sp && x[k].remValNotR(-sum_fixed)) ||
				(k >= sp && y[k].remValNotR(-sum_fixed))) {
			Clause *m_r = NULL;
			if (so.lazy) {
				m_r = Reason_new(sz+R);
                                //m_r->padding = prop_id;
                                //Clause::clause2prop[m_r] = prop_id;
				for (int i = 0; i < k; i++) (*m_r)[i+1] = x[i].getValLit();
				for (int i = k+1; i < sz; i++) (*m_r)[i] = x[i].getValLit();
				if (R) (*m_r)[sz] = r.getValLit();
			}
			if (k < sp) {	if (!x[k].remVal(-sum_fixed, m_r)) return false; }
			else        {	if (!y[k].remVal(-sum_fixed, m_r)) return false; }
		}

		return true;
	}

    void getKey() {        
        if (num_unfixed == sz && (!R || !r.isFixed())) return;
        if (num_unfixed == 0 || r.isFalse()) return;
        if (!r.isFixed()) {
            core_key.push(prop_id);
            core_key.push(sum_fixed);
            core_key.push(0);
        } else if (r.isTrue()) {
            core_key.push(prop_id);
            core_key.push(sum_fixed);
            core_key.push(1);
        } else {
            //No need, empty key
        }
        return;
        
		// Inactive
		if (num_unfixed == sz && (!R || !r.isFixed())) return;
		// Redundant
		if (num_unfixed == 0 || r.isFalse()) return;
		// Get key
		core_key.push(prop_id | ((r.isTrue() ? 1 : 0) << 31));
		core_key.push(sum_fixed);
    }
};

//-----

// sum a*x rel c

template <int S>
void int_linear(vec<int>& a, vec<IntVar*>& x, IntRelType t, int c) {
	vec<int> b; for (int i = 0; i < a.size(); i++) b.push(-a[i]);
	switch (t) {
		case IRT_EQ:
			int_linear<S>(a, x, IRT_GE, c);
			int_linear<S>(b, x, IRT_GE, -c);
			return;
		case IRT_NE:
			new LinearNE<2*S,2*S+1>(a, x, c);
			return;
		case IRT_LE:
			int_linear<S>(b, x, IRT_GE, -c);
			return;
		case IRT_LT:
			int_linear<S>(b, x, IRT_GE, -c+1);
			return;
		case IRT_GE:
			new LinearGE<S>(a, x, c);
			break;
		case IRT_GT:
			int_linear<S>(a, x, IRT_GE, c+1);
			return;
		default: NEVER;
	}

	assert(t == IRT_GE);
	if (so.mip) mip->addConstraint(a, x, c, 1e100);
}


//-----

// sum a*x rel c <-> r

template <int S>
void int_linear_reif(vec<int>& a, vec<IntVar*>& x, IntRelType t, int c, BoolView r) {
	vec<int> b; for (int i = 0; i < a.size(); i++) b.push(-a[i]);
	switch (t) {
		case IRT_EQ:
			new LinearGE<S,1>(a, x, c, r);
			new LinearGE<S,1>(b, x, -c, r);
			new LinearNE<2*S,2*S+1,1>(a, x, c, ~r);
			break;
		case IRT_NE:
			int_linear_reif<S>(a, x, IRT_EQ, c, ~r);
			break;
		case IRT_LE:
			int_linear_reif<S>(b, x, IRT_GE, -c, r);
			break;
		case IRT_LT:
			int_linear_reif<S>(b, x, IRT_GE, -c+1, r);
			break;
		case IRT_GE:
			new LinearGE<S,1>(a, x, c, r);
			new LinearGE<S,1>(b, x, -c+1, ~r);
			break;
		case IRT_GT:
			int_linear_reif<S>(a, x, IRT_GE, c+1, r);
			break;
		default: NEVER;
	}
}

// sum a*x rel c <-> r

void int_linear(vec<int>& a, vec<IntVar*>& x, IntRelType t, int c, BoolView r) {
	assert(a.size() == x.size());

	bool scale = false;
	double limit = abs(c);
	for (int i = 0; i < x.size(); i++) {
		assert(a[i]);
		if (a[i] != 1 && a[i] != -1) scale = true;
		limit += abs(a[i]) * IntVar::max_limit + INT_MAX;
	}
	if (limit >= INT64_MAX) ERROR("Linear constraint may overflow, not yet supported\n");

	if (x.size() == 1 && !scale) {
		if (r.isTrue()) {
			if (a[0] == 1) int_rel(x[0], t, c);
			if (a[0] == -1) int_rel(x[0], -t, -c);
		} else {
			if (a[0] == 1) int_rel_reif(x[0], t, c, r);
			if (a[0] == -1) int_rel_reif(x[0], -t, -c, r);
		}
		return;
	}

	if (x.size() == 2 && !scale) {
		if (r.isTrue()) {
			if (a[0] == -1 && a[1] == -1) bin_linear(x[0], x[1], -t, -c);
			if (a[0] == 1 && a[1] == -1) int_rel(x[0], t, x[1], c);
			if (a[0] == -1 && a[1] == 1) int_rel(x[1], t, x[0], c);
			if (a[0] == 1 && a[1] == 1) bin_linear(x[0], x[1], t, c);
			return;
		} else if (a[0] + a[1] == 0) {
			if (a[0] == 1 && a[1] == -1) int_rel_reif(x[0], t, x[1], r, c);
			if (a[0] == -1 && a[1] == 1) int_rel_reif(x[1], t, x[0], r, c);
			return;
		}
	}

	if (r.isTrue()) {
		if (scale) int_linear<1>(a, x, t, c);
		else       int_linear<0>(a, x, t, c);
	} else {
		if (scale) int_linear_reif<1>(a, x, t, c, r);
		else       int_linear_reif<0>(a, x, t, c, r);
	}
}

void int_linear(vec<IntVar*>& x, IntRelType t, int c, BoolView r) {
	vec<int> a(x.size(),1);
	int_linear(a, x, t, c, r);
}

void int_linear(vec<int>& _a, vec<IntVar*>& _x, IntRelType t, IntVar* y, BoolView r) {
	vec<int> a;
	for (int i = 0; i < _a.size(); i++) a.push(_a[i]);
	a.push(-1);
	vec<IntVar*> x;
	for (int i = 0; i < _x.size(); i++) x.push(_x[i]);
	x.push(y);
	int_linear(a, x, t, 0, r);
}

void int_linear(vec<IntVar*>& x, IntRelType t, IntVar* y, BoolView r) {
	vec<int> a(x.size(),1);
	int_linear(a, x, t, y, r);
}

void table_GAC(vec<IntVar*>& x, vec<vec<int> >& t);

// sum a*x = c, propagated to domain consistency using table propagator

void int_linear_dom(vec<int>& a, vec<IntVar*>& x, int c) {
	assert(a.size() == 3 && x.size() == 3);

	for (int i = 0; i < x.size(); i++) x[i]->specialiseToEL();

	vec<vec<int> > t;
	for (int i = x[0]->getMin(); i <= x[0]->getMax(); i++) {
		if (!x[0]->indomain(i)) continue;
		for (int j = x[1]->getMin(); j <= x[1]->getMax(); j++) {
			if (!x[1]->indomain(j)) continue;
			int k = c - a[0]*i + a[1]*j;
			if (k%a[2] != 0) continue;
			k /= a[2];
			if (!x[2]->indomain(k)) continue;
			t.push();
			t.last().push(i);
			t.last().push(j);
			t.last().push(k);
		}
	}

	table_GAC(x, t);
}

