#include <cstdio>
#include <algorithm>
#include <cassert>
#include "core/options.h"
#include "core/engine.h"
#include "core/sat.h"
#include "core/propagator.h"
#include "mip/mip.h"
#include "parallel/parallel.h"
#include "core/sat-types.h"

#define PRINT_ANALYSIS 0

SAT sat;

cassert(sizeof(Lit) == 4);
cassert(sizeof(Clause) == 4);
cassert(sizeof(WatchElem) == 8);
cassert(sizeof(Reason) == 8);

//---------
// inline methods

//std::unordered_map<Clause*, int> Clause::usage_count;
//std::unordered_map<Clause*, Clause*> Clause::gen_to_learnt;
//std::unordered_map<int, int> Clause::prop2contrib;//How many times a clause genrated by prop went into a learnt clause
//std::unordered_map<Clause*, int> Clause::clause2prop; //for each clause, who created it

inline void SAT::insertVarOrder(int x) {
	if (!order_heap.inHeap(x) && flags[x].decidable) order_heap.insert(x);
}

inline void SAT::setConfl(Lit p, Lit q) {
	(*short_confl)[0] = p;
	(*short_confl)[1] = q;
	confl = short_confl;
}

inline void SAT::untrailToPos(vec<Lit>& t, int p) {
	int dl = decisionLevel();

	for (int i = t.size(); i-- > p; ) {
            int x = var(t[i]);
		assigns[x] = toInt(l_Undef);
#if PHASE_SAVING
		if (so.phase_saving >= 1 || (so.phase_saving == 1 && dl >= l0))
			polarity[x] = sign(t[i]);
#endif
		insertVarOrder(x);
	}
	t.resize(p);
}

//---------
// main methods


SAT::SAT() :
		lit_sort(trailpos)
                ,xuip_per_analysis(0)
                ,analysis_counter(0)
	, pushback_time(0)
	, trail(1)
	, qhead(1,0)
	, rtrail(1)
	, confl(NULL)
	, var_inc(1)
	, cla_inc(1)
	, order_heap(VarOrderLt(activity))
	, bin_clauses(0)
	, tern_clauses(0)
	, long_clauses(0)
	, learnt_clauses(0)
	, propagations(0)
	, back_jumps(0)
	, nrestarts(0)
	, next_simp_db(100000)
	, clauses_literals(0)
	, learnts_literals(0)
	, max_literals(0)
	, tot_literals(0)
	, avg_depth(100)
	, confl_rate(1000)
	, ll_time(wallClockTime())
	, ll_inc(1)
	, learnt_len_el(10)
	, learnt_len_occ(MAX_SHARE_LEN,learnt_len_el*1000/MAX_SHARE_LEN)
    , num_pvars(0)
    ,num_pclauses(0)
    , hhead(0)
    ,sat_key(NULL)
    ,fixed_key(NULL)
{
	newVar(); enqueue(Lit(0,1));
	newVar(); enqueue(Lit(1,0));
	temp_sc = (SClause*) malloc(TEMP_SC_LEN * sizeof(int));
	short_expl = (Clause*) malloc(sizeof(Clause) + 3 * sizeof(Lit));
	short_confl = (Clause*) malloc(sizeof(Clause) + 2 * sizeof(Lit));
	short_expl->clearFlags();
	short_confl->clearFlags();
	short_confl->sz = 2;
}

SAT::~SAT() {
	for (int i = 0; i < clauses.size(); i++) free(clauses[i]);
	for (int i = 0; i < learnts.size(); i++) free(learnts[i]);
}

void SAT::init() {
	orig_cutoff = nVars();
	ivseen.growTo(engine.vars.size(), false);
}

int SAT::newVar(int n, ChannelInfo ci) {
	int s = assigns.size();
	watches  .growBy(n);
	watches  .growBy(n);
	assigns  .growBy(n, toInt(l_Undef));
	reason   .growBy(n, NULL);
	trailpos .growBy(n, -1);
	seen     .growBy(n, 0);
	activity .growBy(n, 0);
	polarity .growBy(n, 1);
	flags    .growBy(n, 7);


	project_no.growBy(n, -1);

	for (int i = 0; i < n; i++) {
		c_info.push(ci);
		ci.val++;
		insertVarOrder(s+i);
	}

	return s;
}

int SAT::getLazyVar(ChannelInfo ci) {
	int v;
	if (var_free_list.size()) {
		v = var_free_list.last();
		var_free_list.pop();
		fprintf(stderr, "reuse %d\n", v);
		assert(assigns[v] == toInt(l_Undef));
		assert(watches[2*v].size() == 0);
		assert(watches[2*v+1].size() == 0);
		assert(num_used[v] == 0);
		c_info[v] = ci;
		activity[v] = 0;
		polarity[v] = 1;
		flags[v] = 7;
	} else {
		v = newVar(1, ci);
		num_used.push(0);
	}
//	flags[v].setDecidable(false);
	return v;
}

void SAT::removeLazyVar(int v) {
	return;
	ChannelInfo& ci = c_info[v];
	assert(assigns[v] == toInt(l_Undef));
	assert(watches[2*v].size() == 0);
	assert(watches[2*v+1].size() == 0);
	fprintf(stderr, "free %d\n", v);
	var_free_list.push(v);
	if (ci.cons_type == 1) {
		((IntVarLL*) engine.vars[ci.cons_id])->freeLazyVar(ci.val);
	} else if (ci.cons_type == 2) {
		engine.propagators[ci.cons_id]->freeLazyVar(ci.val);
	} else NEVER;
}

void SAT::addClause(Lit p, Lit q) {
	if (value(p) == l_True || value(q) == l_True) return;
	if (value(p) == l_False && value(q) == l_False) {
		assert(false);
		TL_FAIL();
	}
	if (value(p) == l_False) {
		assert(decisionLevel() == 0);
		enqueue(q);
		return;
	}
	if (value(q) == l_False) {
		assert(decisionLevel() == 0);
		enqueue(p);
		return;
	}
	bin_clauses++;
	watches[toInt(~p)].push(q);
	watches[toInt(~q)].push(p);
}

void SAT::addClause(vec<Lit>& ps, bool one_watch) {
	int i, j;
	for (i = j = 0; i < ps.size(); i++) {
		if (value(ps[i]) == l_True) return;
		if (value(ps[i]) == l_Undef) ps[j++] = ps[i];
	}
	ps.resize(j);
	if (ps.size() == 0) {
		assert(false);
		TL_FAIL();
	}
	addClause(*Clause_new(ps), one_watch);
}

void SAT::addClause(Clause& c, bool one_watch) {
	assert(c.size() > 0);
	if (c.size() == 1) {
		assert(decisionLevel() == 0);
		if (DEBUG) fprintf(stderr, "warning: adding length 1 clause!\n");
		if (value(c[0]) == l_False) TL_FAIL();
		if (value(c[0]) == l_Undef) enqueue(c[0]);
		free(&c);
		return;
	}
	if (!c.learnt) {
		if (c.size() == 2) bin_clauses++;
		else if (c.size() == 3) tern_clauses++;
		else long_clauses++;
	}

	// Mark lazy lits which are used
	if (c.learnt) { 
            for (int i = 0; i < c.size(); i++) 
                incVarUse(var(c[i]));
        }

	if (c.size() == 2) {
		if (!one_watch) watches[toInt(~c[0])].push(c[1]);
		watches[toInt(~c[1])].push(c[0]);
		if (!c.learnt) free(&c); //No need to worry about 'pending', they are learnt.
		return;
	}
	if (!one_watch) watches[toInt(~c[0])].push(&c);
	watches[toInt(~c[1])].push(&c);
	if (c.learnt) learnts_literals += c.size();
	else            clauses_literals += c.size();
	if (c.learnt) learnts.push(&c);
	else            clauses.push(&c);
}

void SAT::addClauseProj(vec<Lit>& ps) {

    int i, j;
    for (i = j = 0; i < ps.size(); i++) {
        if (value(ps[i]) == l_True) return;
        if (value(ps[i]) == l_Undef) ps[j++] = ps[i];
    }
    ps.resize(j);
    if (ps.size() == 0) {
        assert(false);
        TL_FAIL();
    }
    Clause* cp = Clause_new(ps);
    Clause& c = *cp;
    bool project = true;
    if (!so.use_hash && !so.presolve) project = false;
    assert(c.size() > 0);
    if (c.size() == 1) {
        assert(decisionLevel() == 0);
        if (DEBUG) fprintf(stderr, "warning: adding length 1 clause!\n");
        if (value(c[0]) == l_False) { printf("Top level failure!\n"); exit(0); }
        if (value(c[0]) == l_Undef) enqueue(c[0]);
        free(&c);
        return;
    }
    if (!c.learnt) {
        if (c.size() == 2) bin_clauses++;
        else if (c.size() == 3) tern_clauses++;
        else long_clauses++;
    }

    // Mark lazy lits which are used
    if (c.learnt) { 
        for (int i = 0; i < c.size(); i++) 
            incVarUse(var(c[i]));
    }
    
    if (c.size() == 2) {
        watches[toInt(~c[0])].push(c[1]);
        watches[toInt(~c[1])].push(c[0]);
        if (!c.learnt) free(&c); //No need to worry about 'pending', they are learnt.
        return;
    }
    watches[toInt(~c[0])].push(&c);
    watches[toInt(~c[1])].push(&c);

    if (project && !so.use_static) {        
        //printf("And now the size is %d ---------------- &c = %p\n",c.size(),&c);
        c.project_no() = num_pclauses++;
        for (int i = 0; i < c.size(); i++) {
            int x = var(c[i]);
            if (project_no[x] == -1) project_no[x] = num_pvars++;
            watches[toInt(c[i])].push((Clause*) ((long long) &c + 3)); //Why +3???????
            //watches[toInt(c[i])].push(&c); //Why +3???????
            watches[toInt(c[i])].last().d.type = 3;
        }
    }

    if (c.learnt) learnts_literals += c.size();
    else            clauses_literals += c.size();
    if (c.learnt) learnts.push(&c);
    else            clauses.push(&c);
}

void SAT::removeClause(Clause& c) {
	assert(c.size() > 1);
	watches[toInt(~c[0])].remove(&c);
	watches[toInt(~c[1])].remove(&c);
	if (c.learnt) learnts_literals -= c.size();
	else          clauses_literals -= c.size();

	if (c.learnt) for (int i = 0; i < c.size(); i++) decVarUse(var(c[i]));

        for (int i = 0; i < pending.size(); i++) {
            if(pending[i].c == &c) {
                pending.removeAt(i);
                i--;
            }
        }

	free(&c);
}


void SAT::topLevelCleanUp() {
  assert(decisionLevel() == 0);

	for (int i = rtrail[0].size(); i-- > 0; ) free(rtrail[0][i]);
	rtrail[0].clear();

	if (so.sat_simplify && propagations >= next_simp_db) simplifyDB();

	for (int i = 0; i < trail[0].size(); i++) {
        seen[var(trail[0][i])] = true;
        trailpos[var(trail[0][i])] = -1;
    }
	trail[0].clear();
	qhead[0] = 0;

}

void SAT::simplifyDB() {
	int i, j;
	for (i = j = 0; i < learnts.size(); i++) {
		if (simplify(*learnts[i])) removeClause(*learnts[i]);
		else learnts[j++] = learnts[i];
	}
  learnts.resize(j);
	next_simp_db = propagations + clauses_literals + learnts_literals;
}

bool SAT::simplify(Clause& c) {
	if (value(c[0]) == l_True) return true;
	if (value(c[1]) == l_True) return true;
	int i, j;
	for (i = j = 2; i < c.size(); i++) {
		if (value(c[i]) == l_True) return true;
		if (value(c[i]) == l_Undef) c[j++] = c[i];
	}
	c.sz = j;
	return false;
}


// Use cases:
// enqueue from decision   , value(p) = u  , r = NULL , channel
// enqueue from analyze    , value(p) = u  , r != NULL, channel
// enqueue from unit prop  , value(p) = u  , r != NULL, channel

void SAT::enqueue(Lit p, Reason r) {
	assert(value(p) == l_Undef);
	int v = var(p);
	assigns [v] = toInt(lbool(!sign(p)));
	trailpos[v] = engine.trailPos();
	reason  [v] = r;
	trail.last().push(p);
	ChannelInfo& ci = c_info[v];
	if (ci.cons_type == 1) engine.vars[ci.cons_id]->channel(ci.val, ci.val_type, sign(p));
}

// enqueue from FD variable, value(p) = u/f, r = ?, don't channel

void SAT::cEnqueue(Lit p, Reason r) {
	assert(value(p) != l_True);
	int v = var(p);
	if (value(p) == l_False) {
		if (so.lazy) {
			if (r == NULL) {
				assert(decisionLevel() == 0);
				setConfl();
			} else {
				confl = getConfl(r, p);
				(*confl)[0] = p;
			}
		} else setConfl();
		return;
	}
	assigns [v] = toInt(lbool(!sign(p)));
	trailpos[v] = engine.trailPos();
	reason  [v] = r;
	trail.last().push(p);
}


void SAT::aEnqueue(Lit p, Reason r, int l) {
	assert(value(p) == l_Undef);
	int v = var(p);
	assigns [v] = toInt(lbool(!sign(p)));
	trailpos[v] = engine.trail_lim[l]-1;
	reason  [v] = r;
	trail[l].push(p);
}

void SAT::btToLevel(int level) {
  if (decisionLevel() <= level) return;

	for (int l = trail.size(); l-- > level+1; ) {
		untrailToPos(trail[l], 0);
		for (int i = rtrail[l].size(); i--; ) {
			free(rtrail[l][i]);
		}
	}
  trail.resize(level+1);
	qhead.resize(level+1);
	rtrail.resize(level+1);

        //Caching 
        for (int i = sat_trail.size(); i-- > sat_trail_lim[level]; ) {
            Clause& c = *sat_trail[i];
            assert(c.mark == 1);
            c.mark = 0;
        }
        sat_trail.resize(sat_trail_lim[level]);
        sat_trail_lim.resize(level);

	engine.btToLevel(level);
	if (so.mip) mip->btToLevel(level);

        if (level == 0)
            pending.clear();

}

void SAT::btToPos(int sat_pos, int core_pos) {
	untrailToPos(trail.last(), sat_pos);
	engine.btToPos(core_pos);
}


// Propagator methods:

bool SAT::propagate() {
	int num_props = 0;

	int& qhead = this->qhead.last();
	vec<Lit>& trail = this->trail.last();

	while (qhead < trail.size()) {
		num_props++;

		Lit p = trail[qhead++];          // 'p' is enqueued fact to propagate.
		vec<WatchElem>& ws = watches[toInt(p)];

		if (ws.size() == 0) continue;

		WatchElem *i, *j, *end;

		for (i = j = ws, end = i + ws.size(); i != end; ) {
			WatchElem& we = *i;
			switch (we.d.type) {
			case 1: {
				// absorbed binary clause
				*j++ = *i++;
				Lit q = toLit(we.d.d2);
				switch (toInt(value(q))) {
					case 0: enqueue(q, ~p); break;
					case -1:
						setConfl(q, ~p);
						qhead = trail.size();
						while (i < end) *j++ = *i++;
						break;
					default:;
				}
				continue;
			}
			case 2: {
				// wake up FD propagator
				*j++ = *i++;
				engine.propagators[we.d.d2]->wakeup(we.d.d1, 0);
				continue;
			}
                        case 3: {
                            Clause& c = *we.pt;
                            //printf("Went to new_sat directly\n");
                            new_sat.push((Clause*) ((long long) &c - 3)); //This causes SEGFAULT (it says the sz is 0 ??
                            //new_sat.push(&c);
                            assert(new_sat.last()->size() > 0);
                            *j++ = *i++;
                            continue;
                        }
			default:
				Clause& c = *we.pt;
				i++;

				// Check if already satisfied
				if (value(c[0]) == l_True || value(c[1]) == l_True) {
					*j++ = &c;
                                        continue;
				}

				Lit false_lit = ~p;

				// Make sure the false literal is data[1]:
				if (c[0] == false_lit) c[0] = c[1], c[1] = false_lit;

				// Look for new watch:
				for (int k = 2; k < c.size(); k++)
					if (value(c[k]) != l_False) {
						c[1] = c[k]; c[k] = false_lit;
						watches[toInt(~c[1])].push(&c);
						goto FoundWatch;
					}

				// Did not find watch -- clause is unit under assignment:
				*j++ = &c;
                                //Clause::usage_count[we.pt]++;
				if (value(c[0]) == l_False) {
					confl = &c;
					qhead = trail.size();
					while (i < end)	*j++ = *i++;
				} else {
					enqueue(c[0], &c);
				}
				FoundWatch:;
			}
		}
		ws.shrink(i-j);
	}
	propagations += num_props;

	return (confl == NULL);
}

struct activity_lt { bool operator() (Clause* x, Clause* y) { return x->activity() < y->activity(); } };
void SAT::reduceDB() {
  int i, j;

	std::sort((Clause**) learnts, (Clause**) learnts + learnts.size(), activity_lt());

  for (i = j = 0; i < learnts.size()/2; i++) {
		if (!locked(*learnts[i])) removeClause(*learnts[i]);
		else learnts[j++] = learnts[i];
  }
  for (; i < learnts.size(); i++) {
		learnts[j++] = learnts[i];
  }
  learnts.resize(j);

	if (so.verbosity >= 3) printf("Pruned %d learnt clauses\n", i-j);
}

void SAT::printStats() {
	fprintf(stderr, "%d SAT variables\n", nVars());
	fprintf(stderr, "%d orig bin clauses\n", bin_clauses);
	fprintf(stderr, "%d orig tern clauses\n", tern_clauses);
	fprintf(stderr, "%d orig long clauses (avg. len. %.2f)\n", long_clauses, long_clauses ? (double) (clauses_literals - 3*tern_clauses) / long_clauses : 0);
	fprintf(stderr, "%d learnt clauses (avg. len. %.2f)\n", learnts.size(), learnts.size() ? (double) learnts_literals / learnts.size() : 0);
	fprintf(stderr, "%lld SAT propagations\n", propagations);
	fprintf(stderr, "%lld back jumps\n", back_jumps);
	fprintf(stderr, "%lld natural restarts\n", nrestarts);
	if (so.ldsb) fprintf(stderr, "%.2f pushback time\n", pushback_time);
}


//-----
// Branching methods

bool SAT::finished() {
	assert(so.vsids);
	while (!order_heap.empty()) {
		int x = order_heap[0];
		if (!assigns[x] && flags[x].decidable) return false;
		order_heap.removeMin();
	}
	return true;
}

DecInfo* SAT::branch() {
	if (!so.vsids) return NULL;

	assert(!order_heap.empty());

	int next = order_heap.removeMin();

	assert(!assigns[next]);
	assert(flags[next].decidable);

	return new DecInfo(NULL, 2*next+polarity[next]);
}

void SAT::cleanPendingClausesBelow(int l) {
    for (int i = pending.size() - 1; i >= 0; i--) { 
        struct BackJumpInfo bji = pending[i];
        if (bji.level >= l) { 
            pending.removeAt(i); 
        }
    }

}


int SAT::getConflictLevel() {
    int tp = -1;
    for (int i = 0; i < confl->size(); i++) {
        int l = trailpos[var((*confl)[i])];
        if (l > tp) tp = l;
    }
    int clevel = engine.tpToLevel(tp);

    if (so.sym_static && clevel == 0) {
        btToLevel(0);
        engine.async_fail = true;
        NOT_SUPPORTED;
        // need to abort analyze as well
        return 0;
    }

    return clevel;
}


//-----
// Parallel methods

void SAT::updateShareParam() {
	so.share_param = 16;
/*
	double bmax = so.bandwidth / so.num_threads;
	double bsum = 0;
//	printf("Update share param\n");
	double factor = learnt_len_el * (ll_inc-0.5);
	for (int i = 0; i < MAX_SHARE_LEN; i++) {
		double lps = learnt_len_occ[i]/factor*i;
//		printf("%.3f, ", lps);
		if (bsum + lps > bmax) {
			so.share_param = i-1 + (bmax - bsum) / lps;
			if (so.share_param < 1) so.share_param = 1;
			return;
		}
		bsum += lps;
	}
	so.share_param = MAX_SHARE_LEN;
//	if (rand()%100 == 0) printf("share param = %.1f\n", so.share_param);
*/
}


void SAT::initProject() {
	fixed_key = (int*) calloc((num_pvars+31)/32, sizeof(int));
	sat_key = (int*) calloc((num_pclauses+31)/32, sizeof(int));
}

void SAT::getKey() {
    //return;
	int& qhead = this->qhead.last();
	for (int i = hhead; i < qhead; i++) {
            int pn = project_no[var(trail.last()[i])];
		if (pn == -1) continue;
		trailChange(fixed_key[pn/32], fixed_key[pn/32]^(1<<(pn%32)));
	}
	trailChange(hhead, qhead);

	for (int i = 0; i < new_sat.size(); i++) {
		Clause& c = *new_sat[i];
		if (c.mark == 1) continue;
		c.mark = 1;
		sat_trail.push(&c);
		int pn = c.project_no();
		trailChange(sat_key[pn/32], sat_key[pn/32]^(1<<(pn%32)));
	}
	new_sat.clear();

	core_key.push(-1);
	for (int i = 0; i < (num_pvars+31)/32; i++) {
		core_key.push(fixed_key[i]);
	}
//	for (int i = 0; i < (num_pclauses+31)/32; i++) {
//		core_key.push(sat_key[i]);
//	}
	dom_key.push(-1);
	dom_key.push((num_pclauses+31)/32);
	for (int i = 0; i < (num_pclauses+31)/32; i++) {
		dom_key.push(sat_key[i]);
	}
	dom_key[0]++;

}
