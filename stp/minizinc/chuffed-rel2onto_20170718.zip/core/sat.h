#ifndef sat_h
#define sat_h

#include <climits>
#include <cmath>
#include <map>
#include "support/misc.h"
#include "support/heap.h"
#include "core/sat-types.h"
#include "branching/branching.h"

#define TEMP_SC_LEN 1024
#define MAX_SHARE_LEN 512

class IntVar;
class SClause;

class SAT : public Branching {
	// For sorting Lits in learnt clause
	struct LitSort {
		vec<int>& level;
		bool operator() (Lit i, Lit j) { return (level[var(i)] > level[var(j)]); }
		LitSort(vec<int>& l) : level(l) {}
	} lit_sort;

	// For VSIDS
	struct VarOrderLt {
		const vec<double>&  activity;
		bool operator () (int x, int y) const { return activity[x] > activity[y]; }
		VarOrderLt(const vec<double>&  act) : activity(act) {}
	};


        //For backtracking:
        struct BackJumpInfo {
            int level; //Where I would have backjumped to
            int last_level; //lowest level (biggest decLevel int) that already has the clause
            Clause* c; //The reason for the propagation
            int uniqueID;
            //See SAT::analyze for it's use
        };
        vec<struct BackJumpInfo> pending;
public:

	// Persistent state
        Lit best_sol_lit;
        void cleanPendingClausesBelow(int l); //Remove clauses at level l and below
        int getConflictLevel();

        int xuip_per_analyze;
        int xuip_per_analysis;
        int analysis_counter;

  vec<Clause*> clauses;             // List of problem clauses
  vec<Clause*> learnts;             // List of learnt clauses

	vec<ChannelInfo> c_info;          // Channel info
  vec<vec<WatchElem> > watches;     // Watched lists
  vec<char> assigns;                // The current assignments
  vec<Reason> reason;               // explanation for the variable's current value, or 'NULL' if none
  vec<int> trailpos;                // the trailPos at which the assignment was made
	vec<LitFlags> flags;              // Info about literal

	double pushback_time;

	// Lazy Lit Generation
	int orig_cutoff;
	vec<int> var_free_list;
	vec<int> num_used;

	vec<vec<Lit> > trail;             // Boolean vars fix order
	vec<int> qhead;

	vec<vec<Clause*> > rtrail;        // List of temporary reason clauses

	// Intermediate state
	Clause *confl;
	int index;
	vec<Lit> out_learnt;
        vec< vec<Lit> > out_learnts;
  vec<char> seen;
	vec<bool> ivseen;
	vec<int> ivseen_toclear;
  vec<Lit> analyze_stack;
  vec<Lit> analyze_toclear;
	vec<IntVar*> min_vars;
	SClause *temp_sc;

	Clause *short_expl;
	Clause *short_confl;

	// VSIDS
	double var_inc;                        // Amount to bump variable with.
	double cla_inc;                        // Amount to bump clause with.
	vec<double> activity;                  // A heuristic measurement of the activity of a variable.
	Heap<VarOrderLt> order_heap;           // A priority queue of variables ordered with respect to the variable activity.
	vec<bool> polarity;

	void insertVarOrder(int x);            // Insert a variable in the decision order priority queue.
	void varDecayActivity();               // Decay all variables with the specified factor. Implemented by increasing the 'bump' value instead.
	void varBumpActivity(Lit p);           // Increase a variable with the current 'bump' value.
	void claDecayActivity();               // Decay all clause activities with the specified factor
	void learntLenDecayActivity();
	void learntLenBumpActivity(int l);

	// Statistics
	int bin_clauses, tern_clauses, long_clauses, learnt_clauses;
	long long int propagations, back_jumps, nrestarts, next_simp_db;
  long long int clauses_literals, learnts_literals, max_literals, tot_literals;
	double avg_depth;
	double confl_rate;

	// Parallel

	double ll_time;
	double ll_inc;
	double learnt_len_el;
	vec<double> learnt_len_occ;

	// Propagator methods

	SAT();
	~SAT();
	void init();
	int  newVar(int n = 1, ChannelInfo ci = ci_null);
	int  getLazyVar(ChannelInfo ci = ci_null);
	void removeLazyVar(int v);
	void addClause(Lit p, Lit q);
	void addClause(vec<Lit>& ps, bool one_watch = false);
	void addClause(Clause& c, bool one_watch = false);
        void addClauseProj(vec<Lit>& ps);
	void removeClause(Clause& c);
	void topLevelCleanUp();
	void simplifyDB();
	bool simplify(Clause& c);
	void enqueue(Lit p, Reason r = NULL);
	void cEnqueue(Lit p, Reason r);
	void aEnqueue(Lit p, Reason r, int l);
	void untrailToPos(vec<Lit>& t, int p);
	void btToLevel(int level);
	void btToPos(int sat_pos, int core_pos);
	bool propagate();
	Clause* getExpl(Lit p);
	Clause* _getExpl(Lit p);
	Clause* getConfl(Reason& r, Lit p);


    // Caching stuff
	int num_pvars;
	int num_pclauses;
        int hhead;
	int *fixed_key;
	int *sat_key;
    vec<Clause*> new_sat;
    vec<int> project_no;
    vec<Clause*> sat_trail;
    vec<int> sat_trail_lim;
    void initProject();
    void getKey();


	void reduceDB();
	void printStats();

	// Branching methods

	bool finished();
	double getScore(VarBranch vb) { NEVER; }
	DecInfo* branch();

	// Parallel methods

	void convertToSClause(Clause& c);
	void convertToClause(SClause& sc);
	void addLearnt();
	void updateShareParam();

	// Conflict methods

	void analyze();
	void getLearntClause();
	int findConflictLevel();
	void explainUnlearnable();
	void clearSeen();
	int  findBackTrackLevel(vec<Lit>& lits);


	bool     consistent    ()      const   { return qhead.last() == trail.last().size(); }
	int      nVars         ()      const   { return assigns.size(); }
	int      decisionLevel ()      const   { return trail.size()-1; }
	Lit      decLit        (int i) const   { return trail[i][0]; }
	lbool    value         (Lit p) const   { return toLbool(assigns[var(p)]) ^ sign(p); }
	bool     locked        (Clause& c) const { return reason[var(c[0])].pt == &c && value(c[0]) == l_True; }

	void    newDecisionLevel();
	void    incVarUse(int v);
	void    decVarUse(int v);
	void    setConfl(Lit p = lit_False, Lit q = lit_False);

	bool isRootLevel(int v) const { return engine.trail_lim.size() == 0 || trailpos[v] < engine.trail_lim[0]; }
        //	bool isRootLevel(int v) const { return trailpos[v] < engine.trail_lim[0]; }
	bool isCurLevel(int v) const { return trailpos[v] >= engine.trail_lim.last(); }
	int getLevel(int v) const { 
		for (int i = engine.trail_lim.size(); i--; ) if (trailpos[v] >= engine.trail_lim[i]) return i;
		return 0;
	}

	// Debug Methods

	void printLit(Lit p);
	template <class T> void printClause(T& c);
	void checkConflict();
	void checkExplanation(Clause& c, int clevel, int index);

};

inline void SAT::newDecisionLevel() {
	trail.push();
	qhead.push(0);
	rtrail.push();
        sat_trail_lim.push(sat_trail.size());
}

inline void SAT::incVarUse(int v) {
	v -= orig_cutoff;
	if (v >= 0) num_used[v]++;
}

inline void SAT::decVarUse(int v) {
	v -= orig_cutoff;
	if (v >= 0) num_used[v]--;
}

inline Clause* SAT::getExpl(Lit p) {
	Reason& r = reason[var(p)];
	switch(r.d.type) {
		case 0:
			return r.pt;
		case 1: 
			btToPos(index, trailpos[var(p)]);
			return _getExpl(p);
		default:
			Clause& c = *short_expl;
			c.sz = r.d.type; c[1] = toLit(r.d.d1); c[2] = toLit(r.d.d2);
			return short_expl;
	}
}

extern SAT sat;

#endif
