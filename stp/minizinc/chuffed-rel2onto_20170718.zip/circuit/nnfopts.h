#ifndef __NNFOPTS_H__
#define __NNFOPTS_H__

// #define FULL_PROP
#define INC_REASON
#define WEAKEN
// #define USE_ACT
//#define SORT_LITS

#endif
