"""
Copyright (C) 2016 Data61 CSIRO
Licensed under http://www.apache.org/licenses/LICENSE-2.0 <see LICENSE file>

Serene Python client: Data Integration Software
"""
CODE_VERSION = "0.2.0"

API_VERSION = "v0.2"  # version number of the API
